# 🎯 BOT TELEGRAM ANALISI SCOMMESSE - GUIDA COMPLETA

## 📋 PREREQUISITI

1. **Python 3.8 o superiore** installato sul tuo computer
2. **Token Telegram Bot** (lo hai già creato con @BotFather)
3. **API Key Google Gemini** (gratuita, vedi sotto)

---

## 🔑 STEP 1: OTTIENI LA GEMINI API KEY (GRATUITA)

1. Vai su: https://makersuite.google.com/app/apikey
2. Accedi con il tuo account Google
3. Clicca su "Create API Key"
4. Copia la chiave (inizia con `AIza...`)

**IMPORTANTE:** Gemini è gratuito con 60 richieste al minuto!

---

## 💻 STEP 2: INSTALLAZIONE

### Windows:

1. Apri il Prompt dei comandi (CMD)
2. Vai nella cartella dove hai scaricato i file:
   ```
   cd C:\percorso\cartella\bot
   ```

3. Installa le librerie necessarie:
   ```
   pip install -r requirements.txt
   ```

### Mac/Linux:

1. Apri il Terminale
2. Vai nella cartella:
   ```
   cd /percorso/cartella/bot
   ```

3. Installa le librerie:
   ```
   pip3 install -r requirements.txt
   ```

---

## ⚙️ STEP 3: CONFIGURAZIONE

1. Apri il file `betting_bot_complete.py` con un editor di testo

2. Trova queste righe all'inizio del file:
   ```python
   TELEGRAM_TOKEN = "IL_TUO_TOKEN_QUI"
   GEMINI_API_KEY = "LA_TUA_API_KEY_GEMINI"
   ```

3. Sostituisci con i tuoi dati:
   ```python
   TELEGRAM_TOKEN = "123456789:ABCdefGHIjklMNOpqrsTUVwxyz"  # Il token da @BotFather
   GEMINI_API_KEY = "AIzaSyC..."  # La chiave da Google
   ```

4. Salva il file

---

## 🚀 STEP 4: AVVIA IL BOT

### Windows:
```
python betting_bot_complete.py
```

### Mac/Linux:
```
python3 betting_bot_complete.py
```

Dovresti vedere:
```
🚀 Inizializzazione bot...
✅ Bot attivo e in ascolto!
📱 Invia screenshot su Telegram per iniziare.
```

---

## 📱 STEP 5: USA IL BOT

1. Apri Telegram
2. Cerca il tuo bot (il nome che hai scelto)
3. Invia `/start`
4. Invia uno screenshot della scommessa

### Comandi disponibili:
- `/start` - Messaggio di benvenuto
- `/stats` - Statistiche complete
- `/reset` - Azzera storico (crea backup automatico)
- `/help` - Aiuto

---

## 🎯 COME FUNZIONA

1. **Invii screenshot** → Bot legge automaticamente tutti i dettagli
2. **Estrazione dati** → Sport, partita, giocatore, quota, importo
3. **Ricerca risultati** → Cerca online i risultati (quando disponibili)
4. **Calcolo P/L** → Ti dice vincita/perdita
5. **Statistiche** → Tiene traccia per sport

---

## 📊 ESEMPIO DI UTILIZZO

```
Tu: [invii screenshot NBA]

Bot:
🏀 NBA

⚡ New York Knicks vs Denver Nuggets
📋 Landry Shamet OVER 1.5 tiri da 3
👤 Giocatore: Landry Shamet

💰 Quota: 1.66
💵 Puntata: 150.00€
🎯 Vincita pot.: 249.00€

──────────────────────────────

⏳ Partita non ancora conclusa o in attesa di verifica

📊 RIEPILOGO AGGIORNATO

🏀 NBA: +0.00€ (0V-0P-1In corso)

──────────────────────────────
💰 TOTALE: +0.00€
📊 ROI Totale: +0.0%
💵 Investito: 150.00€
```

---

## ⚠️ LIMITAZIONI ATTUALI

**Ricerca risultati:** Attualmente il bot salva le scommesse ma segna i risultati come "in attesa di verifica". 

Per attivare la ricerca automatica dei risultati serve integrare:
- **API-Football** (gratuita, 100 richieste/giorno)
- **API-Basketball** (gratuita)
- **Rapid API Sports** (varie API gratuite)

Questa è la versione BASE funzionante. Posso aggiungere le API per i risultati automatici se vuoi!

---

## 🔧 RISOLUZIONE PROBLEMI

### "ModuleNotFoundError"
→ Reinstalla: `pip install -r requirements.txt`

### "Invalid token"
→ Controlla di aver copiato correttamente il token da @BotFather

### "API key not valid"
→ Verifica la Gemini API key su https://makersuite.google.com

### Bot non risponde
→ Assicurati che lo script sia in esecuzione (deve mostrare "Bot attivo")

---

## 📝 FILE CREATI

- `betting_history.json` - Storico scommesse
- `backup_YYYYMMDD_HHMMSS.json` - Backup automatici (quando usi /reset)

---

## 🆘 SUPPORTO

Se hai problemi:
1. Verifica di aver seguito tutti gli step
2. Controlla che Python sia installato: `python --version`
3. Controlla le API key

---

## 🎁 PROSSIMI STEP (OPZIONALI)

Posso aggiungere:
✅ Integrazione API per risultati automatici NBA/Calcio/Tennis
✅ Notifiche quando le partite finiscono
✅ Grafici statistiche
✅ Export Excel delle scommesse
✅ Filtri per data/sport
✅ Comparazione bookmaker

Fammi sapere cosa ti serve!
