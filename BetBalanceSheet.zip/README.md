# 🎯 Bot Telegram Analisi Scommesse Sportive

Bot Telegram completo per analizzare automaticamente le tue scommesse sportive e calcolare profitti/perdite per sport.

![NBA](https://img.shields.io/badge/NBA-🏀-orange)
![Calcio](https://img.shields.io/badge/Calcio-⚽-green)
![Tennis](https://img.shields.io/badge/Tennis-🎾-yellow)

## ✨ Funzionalità

✅ **Analisi automatica screenshot** - Invia una foto e il bot estrae tutti i dettagli
✅ **Multi-sport** - NBA, Calcio, Tennis e altri sport
✅ **Calcolo automatico P/L** - Profitti e perdite per ogni scommessa
✅ **Statistiche per sport** - Traccia i tuoi risultati divisi per sport
✅ **ROI tracking** - Calcolo del ritorno sull'investimento
✅ **Storico completo** - Tutte le scommesse salvate in JSON
✅ **Backup automatici** - Ogni volta che azzeri i dati

## 📦 Cosa include

```
📁 betting-bot/
├── 📄 betting_bot_complete.py    # Bot principale (PRONTO ALL'USO)
├── 📄 sports_api.py               # Modulo API per risultati automatici (opzionale)
├── 📄 requirements.txt            # Dipendenze Python
├── 📄 GUIDA_INSTALLAZIONE.md      # Guida completa passo-passo
└── 📄 README.md                   # Questo file
```

## 🚀 Quick Start (5 minuti)

### 1️⃣ Crea il Bot Telegram
```
1. Apri Telegram
2. Cerca @BotFather
3. Invia /newbot
4. Segui le istruzioni
5. COPIA il token (tipo: 123456789:ABCdef...)
```

### 2️⃣ Ottieni API Key Gemini (gratuita)
```
1. Vai su: https://makersuite.google.com/app/apikey
2. Accedi con Google
3. Clicca "Create API Key"
4. COPIA la chiave (inizia con AIza...)
```

### 3️⃣ Installa
```bash
# Scarica le dipendenze
pip install -r requirements.txt

# Apri betting_bot_complete.py e sostituisci:
TELEGRAM_TOKEN = "IL_TUO_TOKEN"     # Token da @BotFather
GEMINI_API_KEY = "LA_TUA_API_KEY"   # Chiave da Google
```

### 4️⃣ Avvia
```bash
python betting_bot_complete.py
```

### 5️⃣ Usa!
```
1. Apri il bot su Telegram
2. Invia /start
3. Invia screenshot delle scommesse
4. Ricevi analisi automatica!
```

## 📱 Comandi Bot

| Comando | Descrizione |
|---------|-------------|
| `/start` | Messaggio di benvenuto |
| `/stats` | Statistiche complete per sport |
| `/reset` | Azzera storico (crea backup) |
| `/help` | Mostra aiuto |

## 📊 Esempio Output

```
🏀 NBA

⚡ New York Knicks vs Denver Nuggets
📋 Landry Shamet OVER 1.5 tiri da 3
👤 Giocatore: Landry Shamet

💰 Quota: 1.66
💵 Puntata: 150.00€
🎯 Vincita pot.: 249.00€

──────────────────────────────

✅ SCOMMESSA VINTA!
💚 Profitto: +99.00€

📊 RIEPILOGO AGGIORNATO

🏀 NBA: +99.00€ (1V-0P-0In corso)
   ROI: +66.0%
⚽ Calcio: -50.00€ (0V-1P-0In corso)
   ROI: -100.0%

──────────────────────────────
💰 TOTALE: +49.00€
📊 ROI Totale: +16.3%
💵 Investito: 300.00€
```

## 🔧 Configurazione Avanzata (Opzionale)

### Risultati Automatici

Per ottenere risultati automatici delle partite, puoi integrare API gratuite:

**1. API-Football** (Calcio)
- 🔗 https://www.api-football.com
- 🆓 100 richieste/giorno gratis
- ⚙️ Istruzioni in `sports_api.py`

**2. API-Basketball** (NBA)
- 🔗 https://rapidapi.com/api-sports/api/api-basketball
- 🆓 100 richieste/giorno gratis
- ⚙️ Istruzioni in `sports_api.py`

**3. API-Tennis** (Tennis)
- 🔗 https://rapidapi.com/api-sports/api/api-tennis
- 🆓 Varie opzioni gratuite

Vedi `sports_api.py` per esempi di integrazione completi.

## 📋 Requisiti

- Python 3.8+
- Internet (per API)
- Account Telegram
- Account Google (per Gemini API)

## 🆓 Costi

**TUTTO GRATUITO!**
- ✅ Telegram Bot: Gratis
- ✅ Google Gemini API: Gratis (60 req/minuto)
- ✅ API sportive base: Gratis (con limiti)

## 🛡️ Privacy

- ✅ Tutti i dati salvati in locale
- ✅ Nessun server esterno
- ✅ Solo tu hai accesso ai tuoi dati
- ✅ API keys private (non condivise)

## 🐛 Problemi Comuni

**Bot non risponde**
→ Verifica che lo script sia in esecuzione

**"Invalid token"**
→ Controlla il token da @BotFather

**"ModuleNotFoundError"**
→ Esegui: `pip install -r requirements.txt`

**Screenshot non letto**
→ Usa immagini nitide e complete

## 📈 Prossimi Sviluppi

- [ ] Notifiche automatiche quando finiscono le partite
- [ ] Grafici statistiche mensili
- [ ] Export Excel
- [ ] Comparazione quote bookmaker
- [ ] Telegram inline keyboard per azioni rapide
- [ ] Sistema di alert per scommesse live

## 🤝 Supporto

Per problemi o domande, consulta `GUIDA_INSTALLAZIONE.md` con guida dettagliata passo-passo.

## 📄 Licenza

Uso personale libero. Non per uso commerciale.

---

**Creato per analizzare scommesse su NBA 🏀, Calcio ⚽, Tennis 🎾 e altri sport!**

**Buone vincite! 💰**
